package stepDefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;

import static io.restassured.RestAssured.*;

public class stepDefination {
	@Given("^the base url$")
	public void the_base_url() {
	    // Write code here that turns the phrase above into concrete actions
		RestAssured.baseURI="https://dog.ceo/api";
		given().log().all().header("Content-Type", "application/json");
	}

	@When("^the user hit the API with the http Get method to find breeds$")
	public void the_user_hit_the_API_with_the_http_Get_method_to_find_breeds() {
	    // Write code here that turns the phrase above into concrete actions
		when().get("breeds/list/all").then().log().all().assertThat().statusCode(200).body("status",equalTo("success"));
	}

@Then("^the user get the successful message$")
	public void the_user_get_the_successful_message() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("success message is returned");
	}

		@When("^the user hit the API with the http Get method and bulldog resource$")
	public void the_user_hit_the_API_with_the_http_Get_method_and_bulldog_resource() {
	    // Write code here that turns the phrase above into concrete actions
	      when().get("breeds/list/all")
		 .then().log().all().assertThat().statusCode(200).body("message.bulldog[0]",is("boston"));
	}

	@Then("^the bulldog is on the list$")
	public void the_bulldog_is_on_the_list() {
	    // Write code here that turns the phrase above into concrete actions
	      System.out.println("bulldog is on the list");
	}

    @When("^the user hit the API with the http Get method and bulldog image resource$")
	public void the_user_hit_the_API_with_the_http_Get_method_and_bulldog_image_resource() {
	    // Write code here that turns the phrase above into concrete actions
	     when().get("breed/bulldog/images")
		.then().log().all().assertThat().statusCode(200).body("status",equalTo("success"));
	}

    @Then("^the 200 is got$")
	public void the_get_status_of() {
	    // Write code here that turns the phrase above into concrete actions
	      System.out.println("get status 200");
	}

   
      @Given("^the pet base url$")
	public void the_pet_base_url() {
	    // Write code here that turns the phrase above into concrete actions
	    RestAssured.baseURI="https://petstore.swagger.io";
		given().log().all().header("Content-Type", "application/json");
	}

    @When("^the user hit the API with the http Get methodd$")
	public void the_user_hit_the_API_with_the_http_Get_methodd() {
	    // Write code here that turns the phrase above into concrete actions
	     when().get("v2/pet/12")
		.then().log().all().statusCode(200).body("status",equalTo("success"));
	}

    @Then("^the user get the successful message and find doggie$")
	public void the_user_get_the_successful_message_and_find_doggie() {
	    // Write code here that turns the phrase above into concrete actions
	     System.out.println("dont get doggie");
	}
	 @Given("^the pet base url and payload$")
  	public void the_pet_base_url_and_payload() {
  	    // Write code here that turns the phrase above into concrete actions
  	    RestAssured.baseURI="https://petstore.swagger.io";
  		given().log().all().header("Content-Type", "application/json").body("{\r\n" + 
				"  \"id\": 120,\r\n" + 
				"  \"category\": {\r\n" + 
				"    \"id\": 0,\r\n" + 
				"    \"name\": \"string\"\r\n" + 
				"  },\r\n" + 
				"  \"name\": \"doggie\",\r\n" + 
				"  \"photoUrls\": [\r\n" + 
				"    \"string\"\r\n" + 
				"  ],\r\n" + 
				"  \"tags\": [\r\n" + 
				"    {\r\n" + 
				"      \"id\": 0,\r\n" + 
				"      \"name\": \"string\"\r\n" + 
				"    }\r\n" + 
				"  ],\r\n" + 
				"  \"status\": \"available\"\r\n" + 
				"}");
  	}

	 @When("^the user hit the API with the http Post method$")
	public void the_user_hit_the_API_with_the_http_Post_method() {
	    // Write code here that turns the phrase above into concrete actions
	     when().post("v2/pet")
		.then().log().all().assertThat().body("status",equalTo("available"));
	    
	}

    @Then("^the get status of 200 on add$")
	public void the_get_status_of_on_add() {
	    // Write code here that turns the phrase above into concrete actions
	     System.out.println("get status equal to availible");
	   
	}

    @When("^the user hit the API with the http Get method with id of added pet$")
	public void the_user_hit_the_API_with_the_http_Get_method_with_id_of_added_pet() {
	    // Write code here that turns the phrase above into concrete actions
	  when().get("v2/pet/120").then().statusCode(200);
	}

    @Then("^the get status of 200 OK when id is used$")
	public void the_get_status_of_OK_when_id_is_used() {
	    // Write code here that turns the phrase above into concrete actions
	     System.out.println("get status 200");
	   
	}
	
}
